// 2021 07 06
#include <iostream>
#include <vector>
using namespace std;

int findContentChildren(vector<int>& g, vector<int>& s) {
    int count = 0;
    sort(g.begin(), g.end());
    sort(s.begin(), s.end());

    for (int i=0; i<g.size(); i++) {
        for (int j=0; j<s.size(); j++) {
            if (g[i] <= s[j]) {
                count++;
                s[j] = 0;
                break;
            }
        }
    } 
    return count;
}

int main() {
    vector<int> g;
    vector<int> s;
    g.push_back(1);
    g.push_back(2);
    //g.push_back(3);

    s.push_back(1);
    s.push_back(2);
    s.push_back(3);

    cout << findContentChildren(g,s) << endl;
}