// 2021 07 11
#include <iostream>
#include <vector>
using namespace std;

vector <vector <int>> generate(int numRows) {
        
}

int main() {
    int numRows = 5;
    generate(numRows);
}